<?php

namespace Drupal\slick\Form;

/**
 * Provides resusable admin functions or form elements.
 */
interface SlickAdminInterface {}
