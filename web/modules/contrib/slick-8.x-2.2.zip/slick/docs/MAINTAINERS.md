***
***
# <a name="maintainers"> </a>MAINTAINERS/CREDITS
* [Gaus Surahman](https://drupal.org/user/159062)
* [Thalles](https://www.drupal.org/u/thalles)
* [Arshadcn](https://www.drupal.org/u/arshadcn)
* [Contributors](https://www.drupal.org/node/2232779/committers)
* CHANGELOG.txt for helpful souls with their patches, suggestions and reports.
* Slick 8.x by gausarts, and other contributors.
* Slick 7.x-3.x by gausarts, based on Slick 8.x-2.x with Blazy.
* Slick 7.x-2.x by gausarts, inspired by Flexslider with CTools integration.
* Slick 7.x-1.x by arshadcn, the original author.


## READ MORE
See the project page on drupal.org:

[Slick Carousel](http://drupal.org/project/slick)

More info relevant to each option is available at their form display by hovering
over them, and clicking a dark question mark.

See the Slick docs at:

* [Slick website](http://kenwheeler.github.io/slick/)
* [Slick at github](https://github.com/kenwheeler/slick/)

[&#10548; Back to Top](#top)
