<?php

namespace Drupal\blazy\Form;

/**
 * Defines re-usable services and functions for blazy plugins.
 */
interface BlazyAdminInterface {}
